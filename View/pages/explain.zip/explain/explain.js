// pages/explain/shouye.js
Page({
  goindex: function () {
    wx.navigateTo({
      url: "../index/index"
    })
  },

})